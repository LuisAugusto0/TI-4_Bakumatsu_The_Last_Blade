using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#nullable enable


namespace Effects.Implementations.TimedEffect
{
    public class PositiveSpeedBonusEffect : UpdatableTimedEffect<SpeedBonusEffect, float>
    {
        public PositiveSpeedBonusEffect(SpeedBonusEffect effect, float duration, Action? onEffectEnd) 
        : base(effect, duration, onEffectEnd) 
        {}

        public override Sprite GetIcon()
        {
            throw new NotImplementedException();
        }
    }  

    public class PositiveDamageBonusEffect : UpdatableTimedEffect<DamageBonusEffect, int>
    {
        public PositiveDamageBonusEffect(DamageBonusEffect effect, float duration, Action? onEffectEnd) 
        : base(effect, duration, onEffectEnd) 
        {}

        public override Sprite GetIcon()
        {
            throw new NotImplementedException();
        }
    }  

    public class HealthBonusEffect : UpdatableTimedEffect<global::HealthBonusEffect, int>
    {
        public HealthBonusEffect(global::HealthBonusEffect effect, float duration, Action? onEffectEnd) 
        : base(effect, duration, onEffectEnd) 
        {}

        public override Sprite GetIcon()
        {
            throw new NotImplementedException();
        }
    }  



    public class DoubleSpeedEffect : UpdatableTimedEffect<SpeedMultiplierEffect, float>
    {
        public DoubleSpeedEffect(EffectReceiver target, float duration, Action? onEffectEnd) 
        : base(GetEffect(target), duration, onEffectEnd) 
        {}

        public static SpeedMultiplierEffect GetEffect(EffectReceiver target)
        {
            return new SpeedMultiplierEffect(target, 1f);
        }

        public override Sprite GetIcon()
        {
            throw new NotImplementedException();
        }
    }  

}