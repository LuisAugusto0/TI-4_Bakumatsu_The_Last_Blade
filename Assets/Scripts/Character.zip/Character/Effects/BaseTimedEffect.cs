using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#nullable enable

/* Local refreshable timer for when to Start / End effect
 *
 * Only accepts non persistant effects that can be ended manually
 * Generic types are used to allow implementation on UpdatableEffect as well
 */
public abstract class TimedEffect<TEffect> : INonPersistantEffect, ITimedStatusEffect, IEffect
where TEffect : BaseEffect, IPersistantEffect {
    protected readonly TEffect effect;
    protected readonly EffectReceiver target;
    readonly Action? onEffectEnd; // Delegate for effect end callback
    float lastActivatedTime = float.MinValue;
    float endTime = float.MinValue;
    public float duration;
    Coroutine? coroutine = null;

    public TimedEffect(TEffect effect, float duration, Action? onEffectEnd) 
    {
        this.target = effect.target;
        this.effect = effect;
        this.duration = duration;
        this.onEffectEnd = onEffectEnd;
    }

    public EffectReceiver GetTarget() => target;
    public abstract Sprite GetIcon();
    public bool IsActive() => coroutine == null;


    public float GetRemainingDuration()
    {
        return endTime - Time.time;
    }


    public void Start() 
    {
        // Inactive to active
        if (coroutine == null)
        {
            target.AddTimedStatusEffect(this);
        }
        else
        {
            // Reset timer
            target.StopCoroutine(coroutine);
        }
        effect.Start();
        lastActivatedTime = Time.time;
        endTime = Time.time + duration;
        coroutine = target.StartCoroutine(Coroutine(this.duration));
        
    }


    public void Refresh(float newTime)
    {
        if (coroutine != null)
        {
            float remainingTime = Time.time - lastActivatedTime;

            // Refresh duration to new higher value, without changing base duration
            if (remainingTime < newTime) 
            {
                target.StopCoroutine(coroutine);
                lastActivatedTime = Time.time;
                endTime = Time.time + newTime;
                coroutine = target.StartCoroutine(Coroutine(newTime));
            }
        }
    }

    public void RefreshDuration(float newDuration)
    {
        Refresh(newDuration);
        this.duration = newDuration;
    }

    IEnumerator Coroutine(float time) 
    {
        yield return new WaitForSeconds(time);
        effect.End();
        target.RemoveTimedStatusEffect(this);
        onEffectEnd?.Invoke();
    }


    public void ForceStop() 
    {
        if (coroutine != null)
        {
            target.StopCoroutine(coroutine);
            effect.End();
            target.RemoveTimedStatusEffect(this);
            onEffectEnd?.Invoke();
        }
    }

    public override string ToString()
    {
        string typeEffect = $"Timed Effect {this.GetType()} for {effect.GetType()} => ";

        if (!IsActive())
        {
            return typeEffect + "Not Active";
        }
     
        return typeEffect + $"Remaning duration: {GetRemainingDuration()}";
    }
}


namespace NamespaceTimedEffect
{
    public class Immunity : TimedEffect<ImmunityEffect>
    {
        public Immunity(ImmunityEffect effect, float duration, Action? onEffectEnd)
        : base(effect, duration, onEffectEnd) 
        {}

        public override Sprite GetIcon()
        {
            throw new NotImplementedException();
        }
    }
}





// Allows updating Effect attributes for Updatable Effects
public abstract class UpdatableTimedEffect<TEffect, TModifier> 
: TimedEffect<TEffect>, IUpdatableEffect<TModifier>

where TEffect : BaseUpdatableEffect<TModifier>, IPersistantEffect
{
    public UpdatableTimedEffect(TEffect effect, float duration, Action? onEffectEnd) 
    : base (effect, duration, onEffectEnd) { }

    public void Update(TModifier modifier) 
    {
        effect.Update(modifier);
    }
}
