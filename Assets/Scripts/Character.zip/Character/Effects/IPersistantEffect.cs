using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#nullable enable

/* Defines effect that persists until End() is called
 *
 * Start() must be safeguarded to not allow consecutive adds
 * Increase in values must only be done using Update from UpdatableEffect<T>
 */
public interface IPersistantEffect : IEffect {
    public void Start();
    public void End();
    public bool IsActive();
}


#region Not Updatable
public class ImmunityEffect : BaseEffect, IPersistantEffect {
    public ImmunityEffect(EffectReceiver target) : base(target) {}
    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start()
    {
        // if immunity was already added, 
        // damageable HashSet will block the consecutive adds
        target.damageable.AddImmunity(this);
        inEffect = true;
    }


    public void End()
    {
        target.damageable.RemoveImmunity(this);
        inEffect = false;
    }
}

#endregion




#region Updatable

public class SpeedBonusEffect : BaseUpdatableEffect<float>, IPersistantEffect {
    public SpeedBonusEffect(EffectReceiver target, float speedBonus) 
    : base(target, speedBonus) {}

    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start() 
    {
        if (inEffect == false)
        {
            target.entityMovement.AddToSpeedBonus(value);
            inEffect = true;
        }
    }

    public void End() 
    {
        target.entityMovement.AddToSpeedBonus(-value);
        inEffect = false;
    }

    public override void Update(float newSpeedBonus) 
    {
        float diff = newSpeedBonus - value;
        target.entityMovement.AddToSpeedBonus(diff);
        this.value += diff;
    }
}


public class SpeedMultiplierEffect : BaseUpdatableEffect<float>, IPersistantEffect {
    public SpeedMultiplierEffect(EffectReceiver target, float speedBonus) 
    : base(target, speedBonus) { }

    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start() 
    {
        if (inEffect == false)
        {
            target.entityMovement.AddToSpeedMultiplier(value);
            inEffect = true;
        }
    }

    public void End() 
    {
        target.entityMovement.AddToSpeedMultiplier(-value);
        inEffect = false;
    }

    public override void Update(float newSpeedMultiplier) 
    {
        float diff = newSpeedMultiplier - value;
        target.entityMovement.AddToSpeedMultiplier(diff);
        this.value += diff;
    }
}

public class DamageBonusEffect : BaseUpdatableEffect<int>, IPersistantEffect {
    public DamageBonusEffect(EffectReceiver target, int damageBonus) 
    : base(target, damageBonus) { }

    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start() 
    {
        if (inEffect == false)
        {
            target.characterDamage.AddDamageBonus(value);
            inEffect = true;
        }
    }

    public void End() 
    {
        target.characterDamage.AddDamageBonus(-value);
        inEffect = false;
    }

    public override void Update(int newDamageBonus) 
    {
        int diff = newDamageBonus - value;
        target.characterDamage.AddDamageBonus(diff);
        this.value += diff;
    }
}

public class DamageMultiplierEffect : BaseUpdatableEffect<float>, IPersistantEffect {
    public DamageMultiplierEffect(EffectReceiver target, float damageMultiplier) 
    : base(target, damageMultiplier) { }

    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start() 
    {
        if (inEffect == false)
        {
            target.characterDamage.AddDamageMultiplier(value);
            inEffect = true;
        }
        
    }

    public void End()
     {
        target.characterDamage.AddDamageMultiplier(-value);
        inEffect = false;
    }

    public override void Update(float newDamageMultiplier) 
    {
        float diff = newDamageMultiplier - value;
        target.characterDamage.AddDamageMultiplier(diff);
        this.value += diff;
    }
} 

public class HealthBonusEffect : BaseUpdatableEffect<int>, IPersistantEffect {
    public HealthBonusEffect(EffectReceiver target, int healthBonus) 
    : base(target, healthBonus) {}

    bool inEffect = false;

    public bool IsActive() => inEffect;

    public override void Start() 
    {
        if (inEffect == false)
        {
            target.damageable.IncreaseBaseHealthBonus(value);
            inEffect = true;
        }

    }

    public void End() 
    {
        target.damageable.IncreaseBaseHealthBonus(-value);
        inEffect = false;
    }

    public override void Update(int newHealthBonus) 
    {
        int diff = newHealthBonus - value;
        target.damageable.IncreaseBaseHealthBonus(diff);
        this.value += diff;
    }
}

// Instantion methods such as healing ring can also be added here


#endregion Updatable

