using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoninPlayerSoundEffects : MonoBehaviour
{
    public SoundEffectPlayer soundFX;
    
    public void Passos(){
        soundFX.FootstepsGrass();
    }
}
