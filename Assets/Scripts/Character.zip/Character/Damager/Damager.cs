using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Used to group different damagers
public class Damager : MonoBehaviour
{ }
