using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Effects.Implementations.TimedEffect;

// Scales by updating effect
// public abstract class BaseUpdatableUpgradeAfterEvent<TEffect, TModifier> : Upgrade
//     where TEffect : UpdatableEffect<TModifier>, IPersistantEffect
// { 
//     // How much each subsequent quantity after 1 affects the effect duration
//     public static float timeMultiplier = 1f;

//     protected UpdatableTimedEffect<TEffect, TModifier> timedEffect;
//     protected Coroutine activeCoroutine = null;

//     public BaseUpdatableUpgradeAfterEvent(UpgradeManager entity, int quantity) 
//     : base(entity, quantity) 
//     {
//         this.timedEffect = CreateTimedEffect();

//     }

//     protected abstract UpdatableTimedEffect<TEffect, TModifier> CreateTimedEffect();
//     protected abstract TModifier GetNewModifier();  
//     protected abstract float GetBaseDuration();

//     protected override void UpdateQuantity(int quantity)
//     {
//         base.UpdateQuantity(quantity);
//         timedEffect.Update(GetNewModifier());
//     }


//     public override void Remove() {
//         base.Remove();
//         timedEffect.ForceStop();
//     }
// }



// Scales by updating effect
public abstract class BaseUpdatableUpgradeAfterEvent<TEffect, TModifier> : Upgrade
    where TEffect : IUpdatableEffect<TModifier>, INonPersistantEffect 
{ 
    // How much each subsequent quantity after 1 affects the effect duration
    public static float timeMultiplier = 1f;

    protected TEffect timedEffect;
    protected Coroutine activeCoroutine = null;

    public BaseUpdatableUpgradeAfterEvent(UpgradeManager entity, int quantity) 
    : base(entity, quantity) 
    {
        this.timedEffect = CreateTimedEffect();

    }

    protected abstract TEffect CreateTimedEffect();
    protected abstract TModifier GetNewModifier();  
    protected abstract float GetBaseDuration();

    protected override void UpdateQuantity(int quantity)
    {
        base.UpdateQuantity(quantity);
        timedEffect.Update(GetNewModifier());
    }


    public override void Remove() {
        base.Remove();
    }
}



public abstract class BaseSpeedBonusAfterHitUpgrade 
: BaseUpdatableUpgradeAfterEvent<UpdatableTimedEffect<SpeedBonusEffect, float>, float> {

    public BaseSpeedBonusAfterHitUpgrade(UpgradeManager target, int quantity)
    : base(target, quantity) 
    {
        SubscribeToOnHitEvent();
    }

    public abstract float GetSpeedBonus();


    private void SubscribeToOnHitEvent()
    {
        target.effectReceiver.damageable.onHit.AddListener(
            (object o, Damageable d) => timedEffect.Start()
        );
    }

    protected override UpdatableTimedEffect<SpeedBonusEffect, float> CreateTimedEffect()
    {
        return new PositiveSpeedBonusEffect(
            new SpeedBonusEffect(target.effectReceiver, GetSpeedBonus()), 
            GetBaseDuration(),
            null
        );
    }

    protected override float GetNewModifier()
    {
        return quantity * GetSpeedBonus();
    }
}


public class SpeedBonusAfterHitUpgrade : BaseSpeedBonusAfterHitUpgrade 
{
    public static readonly float BaseDuration = 2f;
    public static readonly float BaseBonus = 2f;

    public SpeedBonusAfterHitUpgrade(UpgradeManager target, int quantity)
    : base(target, quantity) {}

    public override float GetSpeedBonus() => BaseBonus;
    protected override float GetBaseDuration() => BaseDuration;
}

public class HighSpeedBonusAfterHitUpgrade : BaseSpeedBonusAfterHitUpgrade 
{
    public static readonly float BaseDuration = 3f;
    public static readonly float BaseBonus = 4f;

    public HighSpeedBonusAfterHitUpgrade(UpgradeManager target, int quantity)
    : base(target, quantity) {}

    public override float GetSpeedBonus() => BaseBonus;
    protected override float GetBaseDuration() => BaseDuration;
}





public abstract class BaseDamageBonusAfterHit 
: BaseUpdatableUpgradeAfterEvent<UpdatableTimedEffect<DamageBonusEffect, int>, int> {


    public BaseDamageBonusAfterHit(UpgradeManager target, int quantity)
    : base(target, quantity) 
    {
        SubscribeToOnHitEvent();
    }

    public abstract int GetDamageBonus();


    private void SubscribeToOnHitEvent()
    {
        target.effectReceiver.damageable.onHit.AddListener(
            (object o, Damageable d) => timedEffect.Start()
        );
    }

    protected override UpdatableTimedEffect<DamageBonusEffect, int> CreateTimedEffect()
    {
        return new PositiveDamageBonusEffect(
            new DamageBonusEffect(target.effectReceiver, GetDamageBonus()), 
            GetBaseDuration(), 
            null
        );
    }

    protected override int GetNewModifier()
    {
        return quantity * GetDamageBonus();
    }
}


public class DamageBoostAfterHitUpgrade : BaseDamageBonusAfterHit 
{
    public static readonly int BaseBonus = 2;
    public static readonly float BaseDuration = 2f;
 
    public DamageBoostAfterHitUpgrade(UpgradeManager target, int quantity)
    : base(target, quantity) {}

    public override int GetDamageBonus() => BaseBonus;
    protected override float GetBaseDuration() => BaseDuration;
}

