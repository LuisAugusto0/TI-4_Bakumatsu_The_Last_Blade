using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.Events;
using Unity.VisualScripting;


[RequireComponent(typeof(EffectReceiver))]
public class StatusEffectManager : MonoBehaviour
{
    // Components used to change attributes / do certain effects
    [NonSerialized] public EffectReceiver effectReceiver;

    [Serializable]
    public class StatusEffectUpdatedEvent : UnityEvent<Type> {}

    // Dictionary of current active effects
    [NonSerialized] 
    public Dictionary<Type, ITimedUniqueStatusEffect> timedEffects = new();
    
    [NonSerialized] 
    public Dictionary<Type, IChargeUniqueStatusEffect> chargeEffects = new();



    public StatusEffectUpdatedEvent OnStatusEffectUpdated; 

    void Awake()
    {
        effectReceiver = GetComponent<EffectReceiver>();
    }

    public void ClearEffects()
    {
        foreach (ITimedUniqueStatusEffect effect in timedEffects.Values)
        {
            effect.Remove();
        }

        foreach (IChargeUniqueStatusEffect effect in chargeEffects.Values)
        {
            effect.Remove();
        }

        OnStatusEffectUpdated.Invoke(null);
    }

 
    public void AddTimedEffect<T>(float duration) where T : ITimedUniqueStatusEffect
    {
        if (duration <= 0)
        {
            Debug.LogError("Cannot refresh to negative duration");
            return;
        }

        var upgradeType = typeof(T);

        if (!timedEffects.ContainsKey(upgradeType))
        {
            var effect = (T)Activator.CreateInstance(upgradeType, this, duration);
            timedEffects[upgradeType] = effect;
        }
        else
        {
            timedEffects[upgradeType].GetEffectReference().Refresh(duration); // How to deal with updates?
        }

        OnStatusEffectUpdated.Invoke(upgradeType);
    }

    public void AddChargeEffect<T>(int charges) where T : IChargeUniqueStatusEffect
    {
        if (charges <= 0)
        {
            Debug.LogError("Cannot refresh to negative duration");
            return;
        }

        var effectType = typeof(T);

        if (!chargeEffects.ContainsKey(effectType))
        {
            var effect = (T)Activator.CreateInstance(effectType, this, charges);
            chargeEffects[effectType] = effect;
        }
        else
        {
            chargeEffects[effectType].GetEffectReference().Refresh(charges); // How to deal with updates?
        }

        OnStatusEffectUpdated.Invoke(effectType);
    }

    // Force remove instance regardless of quantity
    public void RemoveTimedEffect(Type upgradeType)
    {
        if (timedEffects.ContainsKey(upgradeType))
        {
            timedEffects.Remove(upgradeType);
            OnStatusEffectUpdated.Invoke(upgradeType);
        }
    }

    public void RemoveChargeEffect(Type upgradeType)
    {
        if (chargeEffects.ContainsKey(upgradeType))
        {
            chargeEffects.Remove(upgradeType);
            OnStatusEffectUpdated.Invoke(upgradeType);
        }
    }



}

