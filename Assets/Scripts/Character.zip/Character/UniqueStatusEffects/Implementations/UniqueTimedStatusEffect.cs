using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using Effects.Implementations;
using Effects.Implementations.TimedEffect;
using Effects.Implementations.ChargeRepeatingEffects;

namespace UniqueStatusEffects.Implementations.UniqueTimedEffects {
    public class BasicSpeedBonus : BaseTimedUniqueStatusEffect<PositiveSpeedBonusEffect>
    {
        const float speedBonus = 1f;
        
        public BasicSpeedBonus(StatusEffectManager target, float totalTime) 
        : base(target, totalTime) {}


        public override PositiveSpeedBonusEffect GetEffect(EffectReceiver target, float duration)
        {
            return new PositiveSpeedBonusEffect(
                new SpeedBonusEffect(target, speedBonus),
                duration,
                Remove
            );
        }
    }
}

