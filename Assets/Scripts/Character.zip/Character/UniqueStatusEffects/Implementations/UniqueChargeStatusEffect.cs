using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using Effects.Implementations.TimedEffect;
using Effects.Implementations.ChargeRepeatingEffects;

namespace UniqueStatusEffects.Implementations.UniqueTimedEffects {
    public class Burning : BaseChargeUniqueStatusEffect<ChargeRepeatingBurningEffect>
    {
        public Burning(StatusEffectManager target, int baseCharges) 
        : base(target, baseCharges) {}

        public override ChargeRepeatingBurningEffect GetEffect(EffectReceiver target, int charges)
        {
            return new ChargeRepeatingBurningEffect(
                target,
                charges,
                Remove
            );
        }
    }
}

