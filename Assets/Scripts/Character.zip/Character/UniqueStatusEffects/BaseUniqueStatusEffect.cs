using System;
using Unity.VisualScripting;
#nullable enable

public interface IUniqueStatusEffect<T>
{
    public void Remove();
}

public abstract class BaseUniqueStatusEffect<TEffect, TValue>
where TEffect : IStatusEffect
{
    public readonly StatusEffectManager manager;
    public readonly TEffect effect;
    
    public BaseUniqueStatusEffect(StatusEffectManager manager, TValue value)
    {
        this.manager = manager;
        this.effect = GetEffect(manager.effectReceiver, value);
    }

    public abstract TEffect GetEffect(EffectReceiver target, TValue value);
    public abstract void Remove();
}



public interface ITimedUniqueStatusEffect : IUniqueStatusEffect<float>
{
    public ITimedStatusEffect GetEffectReference();
}

public abstract class BaseTimedUniqueStatusEffect<TEffect> 
: BaseUniqueStatusEffect<TEffect, float>, ITimedUniqueStatusEffect 
where TEffect : ITimedStatusEffect
{
    public BaseTimedUniqueStatusEffect(StatusEffectManager manager, float value)
    : base(manager, value) {}

    public ITimedStatusEffect GetEffectReference() => effect;


    public override void Remove()
    {
        manager.RemoveTimedEffect(this.GetType());
    }
}



public interface IChargeUniqueStatusEffect : IUniqueStatusEffect<float>
{
    public IChargeStatusEffect GetEffectReference();
}

public abstract class BaseChargeUniqueStatusEffect<TEffect> 
: BaseUniqueStatusEffect<TEffect, int> where TEffect : IChargeStatusEffect
{
    public BaseChargeUniqueStatusEffect(StatusEffectManager manager, int baseCharges)
    : base(manager, baseCharges) {}

    public IChargeStatusEffect GetGenericEffectReference() => effect;

    public override void Remove()
    {
        manager.RemoveChargeEffect(this.GetType());
    }
}



