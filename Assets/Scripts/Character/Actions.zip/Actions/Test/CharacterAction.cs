using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ICharacterAction
{
    void Start();
}

public interface ICancellableCharacterAction : ICharacterAction
{
    void Cancel();
}


public interface ManagedCharacterAction
{
    public bool Attempt();
    public bool IsReady();
}





public class EntityActionHandler<TAction> : ScriptableObject
where TAction : ICharacterAction
{
    public TAction action;
    public TAction GetAction() => action;
}

