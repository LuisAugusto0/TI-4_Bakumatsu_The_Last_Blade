using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


[Serializable]
public class BasePersistantCooldownAction<TAction, TCooldown> : ManagedCharacterAction
    where TAction : ICancellableCharacterAction  
    where TCooldown : ICooldown
{
    [SerializeField]
    readonly TAction action;
    public readonly TCooldown cooldown;
    public readonly Character target;

    bool onAction = false;

    public BasePersistantCooldownAction(Character target, TAction action, TCooldown cooldown)
    {
        this.action = action;
        this.cooldown = cooldown;
        this.target = target;
    }   
    
    public bool IsReady() => !target.IsActionLocked && !onAction && cooldown.IsReadyForUse();

    public bool Attempt()
    {
        if (target.IsActionLocked || onAction) return false;

        bool activated = cooldown.AttemptActivation();
        if (activated)
        {   
            action.Start();
        }
        
        onAction = true;
        return activated;
    }

    protected void End()
    {
        onAction = false;
    }

    public void Cancel()
    {
        action.Cancel();
    }
}