using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class RoninDodgeRollManagedAction : EntityActionHandler<RoninDodgeRollAction>
{
    public float speedMultiplier = 1.2f;
    public float perfectDodgeWindow = 1f;
    public float cooldown = 1f;
    public int charges = 3;

    public DodgeRollCooldownAction<ChargeCooldown<Character>> GetAction(RoninPlayerBehaviourHandler target)
    {
        return new DodgeRollCooldownAction<ChargeCooldown<Character>>(
            target.character, GetAction(target, null), GetCooldown(target.character)
        );
    }

    public ChargeCooldown<Character> GetCooldown(Character target)
    {
        return new ChargeCooldown<Character>(target, charges, cooldown);
    }

    public RoninDodgeRollAction GetAction(RoninPlayerBehaviourHandler target, OnActionEnded finishedCallback)
    {
        return new RoninDodgeRollAction(target, finishedCallback, speedMultiplier, perfectDodgeWindow);
    }
}


public class DodgeRollCooldownAction<TCooldown> 
: BasePersistantCooldownAction<RoninDodgeRollAction, TCooldown>
where TCooldown : ICooldown
{
    public DodgeRollCooldownAction(
        Character target, 
        RoninDodgeRollAction action, 
        TCooldown cooldown
    ) : base(target, action, cooldown)
    { }
}



public class RoninDodgeRollAction : ICancellableCharacterAction
{
    readonly RoninPlayerBehaviourHandler target;
    readonly DirectionalMovement movement;
    readonly OnActionEnded finishedCallback;
    readonly Character character;
    
    readonly float speedMultiplier;
    readonly float perfectDodgeWindow;
    
    bool isActive;
    Vector2 moveVector = Vector2.zero;

    public RoninDodgeRollAction(
        RoninPlayerBehaviourHandler target, 
        OnActionEnded callback, 
        float speedMultiplier, 
        float perfectDodgeWindow
    )
    {
        this.target = target;
        this.movement = target.movement;
        this.character = target.character;
        this.finishedCallback = callback;
        this.perfectDodgeWindow = perfectDodgeWindow;
        this.speedMultiplier = speedMultiplier;
        
    }

    public void Start()
    {
        if (!isActive)
        {
            Vector2 dir = target.LastMoveInputVector == Vector2.zero ?
                movement.GetFacingDirectionVector2() : target.LastMoveInputVector.normalized;

            moveVector = dir * (speedMultiplier * movement.CurrentSpeed);

            target.actionAnimationEvent = OnRollAnimationEvent;
            target.animator.SetTrigger(RoninPlayerBehaviourHandler.rollTriggerHash);

            character.damageable.AddImmunity(this);
            character.StartActionLock(Cancel, this);
            
            character.damageable.onHit.AddListener(HitOnPerfectDodgeWindow);
            target.StartCoroutine(PerfectDashTime());

            isActive = true;
            target.StartCoroutine(DashRoutine());
        }
    }

    void HitOnPerfectDodgeWindow(object source, Damageable damageable)
    {
        Debug.Log("PERFECT DODGE!!");
    }


    IEnumerator PerfectDashTime()
    {
        yield return new WaitForSeconds(perfectDodgeWindow);
        character.damageable.onHit.RemoveListener(HitOnPerfectDodgeWindow);
    }


    IEnumerator DashRoutine() 
    {
        while (isActive) 
        {
            movement.MoveTowardsMoveVector(moveVector);
            yield return new WaitForFixedUpdate();
        }
    }


    void OnRollAnimationEvent(int context)
    {
        switch(context) {
            case 0:
                //Starting to roll
                break;
            case 1:
                // Ended Roll
                break;
            case 2:
                // Ended Animation
                End();
                break;
            default:
                Debug.LogErrorFormat("");
                break;
        }   
    }

    // When animation truly finished
    void End()
    {
        character.damageable.RemoveImmunity(this);
        character.EndActionLock(this);
        target.actionAnimationEvent = null;
        finishedCallback.Invoke();
        isActive = false;
    }

    public void Cancel()
    {
        character.damageable.RemoveImmunity(this);
        End();
    }
}

