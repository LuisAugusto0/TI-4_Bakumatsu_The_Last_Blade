using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


[Serializable]
public class BaseInstantaneousCooldownAction<TAction, TCooldown> : ManagedCharacterAction
    where TAction : ICharacterAction  
    where TCooldown : ICooldown
{
    [SerializeField]
    readonly TAction action;
    public readonly TCooldown cooldown;
    public readonly Character target;

    public BaseInstantaneousCooldownAction(Character target, TAction action, TCooldown cooldown)
    {
        this.action = action;
        this.cooldown = cooldown;
        this.target = target;
    }   
    
    public virtual bool IsReady() => !target.IsActionLocked && cooldown.IsReadyForUse();

    public virtual bool Attempt()
    {
        if (target.IsActionLocked) return false;

        bool activated = cooldown.AttemptActivation();
        if (activated)
        {   
            action.Start();
        }
        
        return activated;
    }
}

