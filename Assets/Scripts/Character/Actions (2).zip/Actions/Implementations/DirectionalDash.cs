using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
#nullable enable



public class DirectionDashManagedAction 
: MonoBehaviour, ICancellableActionPrefabFactory<RoninPlayerBehaviourHandler>
{
    public float speedMultiplier = 1.2f;
    public float perfectDodgeWindow = 1f;
    public float duration = 2f;
    public float cooldown = 1f;
    public int charges = 3;

    public IManagedCharacterAction GetIManagedAction(
        RoninPlayerBehaviourHandler target, OnActionEnded finishedCallback
    )
    {
        return GetManagedAction(target, finishedCallback);
    }

    public DirectionDashChargeCooldown GetManagedAction(RoninPlayerBehaviourHandler target, OnActionEnded finishedCallback)
    {
        return new DirectionDashChargeCooldown(
            target.character, GetAction(target, ()=>{}), GetCooldown(target.character)
        );
    }

    ChargeCooldown<Character> GetCooldown(Character target)
    {
        return new ChargeCooldown<Character>(target, charges, cooldown);
    }

    RoninDodgeRoll GetAction(RoninPlayerBehaviourHandler target, OnActionEnded finishedCallback)
    {
        return new RoninDodgeRoll(target, finishedCallback, speedMultiplier, perfectDodgeWindow);
    }
}


// Define roll is charge cooldown action
[Serializable]
public class DirectionDashChargeCooldown
: ManagedPersistantCooldownAction<RoninDodgeRoll, ChargeCooldown<Character>>
{
    public DirectionDashChargeCooldown(
        Character target, 
        RoninDodgeRoll action, 
        ChargeCooldown<Character> cooldown
    ) : base(target, action, cooldown)
    { }
}


public class DirectionalDash : IPersistantCharacterAction
{
    [Serializable]
    public class OnDashEvent : UnityEvent<DirectionalDash>
    { }

    public readonly AbstractPlayerBehaviourHandler player;
    public readonly DirectionalMovement movement;
    public readonly Character character;
    
    public readonly float speed;
    public readonly float duration;

    readonly OnActionEnded finished;

    Vector2 moveVector = Vector2.zero; 
    Coroutine? dashCoroutine;
    Coroutine? timerCoroutine;

    public DirectionalDash(
        AbstractPlayerBehaviourHandler player, 
        float speed, 
        float duration,
        OnActionEnded finished
    )
    {
        this.player = player;
        character = player.character;
        movement = player.directionalMovement;

        this.speed = speed;
        this.duration = duration;
        this.finished = finished;
    }



    public void ActionStart()
    {
        moveVector = movement.LastMoveVector == Vector2.zero ? 
            movement.GetFacingDirectionVector2() : movement.LastMoveVector;

        character.StartActionLock(ForceCancel, this);
        character.damageable.AddImmunity(this);

        dashCoroutine = movement.StartCoroutine(DashRoutine());
        timerCoroutine = movement.StartCoroutine(TimerRoutine());
    }


    IEnumerator TimerRoutine()
    {
        yield return new WaitForSeconds(duration);
        timerCoroutine = null;
        End();
    }

    IEnumerator DashRoutine() 
    {
        while (true) 
        {
            movement.MoveTowardsMoveVector(moveVector);
            yield return new WaitForFixedUpdate();
        }
    }

    void End()
    {
        movement.StopCoroutine(dashCoroutine);
        dashCoroutine = null;

        character.EndActionLock(this);
        character.damageable.RemoveImmunity(this);
        finished.Invoke();
    }

    public void ForceCancel()
    {
        if (timerCoroutine != null)
        {
            movement.StopCoroutine(timerCoroutine);
            timerCoroutine = null;
        }

        End();
    }

    // No implementations
    public bool AttemptCancel()
    { 
        ForceCancel();
        return true;
    }
}
