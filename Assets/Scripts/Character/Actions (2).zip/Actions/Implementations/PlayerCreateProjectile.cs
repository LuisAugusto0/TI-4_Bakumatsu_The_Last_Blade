using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
#nullable enable


public class PlayerCreateProjectileManagedAction 
: MonoBehaviour, IActionPrefabFactory<AbstractPlayerBehaviourHandler>
{
    public GameObject? prefab;
    public Transform? spawnPos; //Use children to offset spawn pos from center
    public float rotationOffset;

    public float distance;  
    public int charges;
    public float cooldown;
    
    public IManagedCharacterAction GetIManagedAction(AbstractPlayerBehaviourHandler target)
    {
        return GetManagedAction(target);
    }
    
    public PlayerCreateProjectileChargeCooldownAction GetManagedAction(AbstractPlayerBehaviourHandler target)
    {
        return new PlayerCreateProjectileChargeCooldownAction(
            target.character, GetAction(target), GetCooldown(target.character)
        );
    }

    public PlayerCreateProjectile GetAction(AbstractPlayerBehaviourHandler target)
    {
        if (prefab == null || spawnPos == null)
        {
            throw new NullReferenceException("Expected serialized references are null");
        }

        return new PlayerCreateProjectile(
            target, 
            prefab, 
            rotationOffset,
            spawnPos
        );
    }

    ChargeCooldown<Character> GetCooldown(Character target)
    {
        return new ChargeCooldown<Character>(target, charges, cooldown);
    }
}



// Define roll is charge cooldown action
public class PlayerCreateProjectileChargeCooldownAction
: ManagedPersistantCooldownAction<PlayerCreateProjectile, ChargeCooldown<Character>>
{
    public PlayerCreateProjectileChargeCooldownAction(
        Character target, 
        PlayerCreateProjectile action, 
        ChargeCooldown<Character> cooldown
    ) : base(target, action, cooldown)
    { }
}

public class PlayerCreateProjectile : IPersistantCharacterAction
{

    public readonly AbstractPlayerBehaviourHandler player;
    public readonly GameObject prefab;
    public readonly float rotationOffset;
    public readonly Transform spawnPos;

    public PlayerCreateProjectile(
        AbstractPlayerBehaviourHandler player,
        GameObject prefab, 
        float rotationOffset,
        Transform spawnPos
    )
    {
        this.player = player;
        this.prefab = prefab;
        this.rotationOffset = rotationOffset;
        this.spawnPos = spawnPos;
    }

    public void ForceCancel() {}
    public bool AttemptCancel() => false;
    
    public void ActionStart()
    {

        float angle = Mathf.Atan2(player.LastPointDirection.y, player.LastPointDirection.x) * Mathf.Rad2Deg;

        angle += rotationOffset;
        
        Quaternion rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        UnityEngine.Object.Instantiate(prefab, spawnPos.position, rotation);
    }

    

}


