using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void OnActionEnded();

public interface IBaseCharacterAction
{
    void ActionStart();

    // Non persistant actions expects both to be empty or return false
    void ForceCancel();
    bool AttemptCancel();
}

// Expects no cooldown to relay on finished
public interface INonPersistantCharacterAction : IBaseCharacterAction
{}

// Expects to relay on finished and to not be called until then
public interface IPersistantCharacterAction : IBaseCharacterAction
{
    OnActionEnded GetOnActionEnded();
}







// public class EntityActionHandler<TAction> : MonoBehaviour
// where TAction : ICharacterAction
// {
//     public TAction action;
// }

