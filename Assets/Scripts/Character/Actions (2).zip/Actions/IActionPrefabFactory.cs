using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IBaseActionPrefabFactory<T>
{

}

public interface IActionPrefabFactory<T> : IBaseActionPrefabFactory<T>
{
    IManagedCharacterAction GetIManagedAction(T target);
}

public interface ICancellableActionPrefabFactory<T> : IBaseActionPrefabFactory<T>
{
    IManagedCharacterAction GetIManagedAction(T target, OnActionEnded finishedCallback);
}
