using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IManagedCharacterAction
{
    bool Attempt();
    bool IsReady();
    IBaseCharacterAction GetAction();
}

public abstract class BaseManagedAction
{
    public readonly IBaseCharacterAction action;
    public BaseManagedAction(IBaseCharacterAction action)
    {
        this.action = action;
    }

    public abstract bool IsReady();
    public abstract bool Attempt();

}

// public abstract class BaseManagedAction<TAction>
// where TAction : IBaseCharacterAction
// {
//     public readonly TAction action;
//     public BaseManagedAction(TAction action)
//     {
//         this.action = action;
//     }

//     public abstract bool IsReady();
//     public abstract bool Attempt();

// }
