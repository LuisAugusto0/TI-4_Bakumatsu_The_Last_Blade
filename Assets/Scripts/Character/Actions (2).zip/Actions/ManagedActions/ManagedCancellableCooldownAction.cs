using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
#nullable enable

[Serializable]
public class ManagedPersistantCooldownAction<TCooldown> : BaseManagedAction
    where TCooldown : ICooldown
{
    public readonly TCooldown cooldown;
    public readonly Character target;
    readonly OnActionEnded? ended;

    bool onAction = false;

    public ManagedPersistantCooldownAction(
        Character target, 
        IPersistantCharacterAction action, 
        OnActionEnded? ended,
        TCooldown cooldown
    ) : base(action)
    {
        this.cooldown = cooldown;
        this.ended = ended;
        this.target = target;
    }   

    public override bool IsReady() => !target.IsActionLocked && !onAction && cooldown.IsReadyForUse();

    public override bool Attempt()
    {
        if (target.IsActionLocked || onAction) return false;

        bool activated = cooldown.AttemptActivation();
        if (activated)
        {   
            action.ActionStart();
        }
        
        onAction = true;
        return activated;
    }

    protected void End()
    {
        onAction = false;
    }

    public void Cancel()
    {
        action.ForceCancel();
    }
    

}