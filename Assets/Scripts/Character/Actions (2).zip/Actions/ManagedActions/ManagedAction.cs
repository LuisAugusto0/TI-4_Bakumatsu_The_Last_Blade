using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagedNonPersistantAction<TAction> : BaseManagedAction
    where TAction : IPersistantCharacterAction  
{
    [SerializeField]
    public readonly Character target;

    public IBaseCharacterAction GetAction() => action;

    public ManagedNonPersistantAction(Character target, TAction action)
    : base(action)
    {
        this.target = target;
    }   
    
    public override bool IsReady() => !target.IsActionLocked;

    public override bool Attempt()
    {
        if (target.IsActionLocked) return false;


        action.ActionStart();
        return true;
    }

}
