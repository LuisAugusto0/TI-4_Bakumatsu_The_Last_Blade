using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
#nullable enable

[Serializable]
public class ManagedNonPersistantCooldownAction<TCooldown> : BaseManagedAction
    where TCooldown : ICooldown
{
    [SerializeField]
    public readonly TCooldown cooldown;
    public readonly Character target;


    public ManagedNonPersistantCooldownAction(
        Character target, 
        INonPersistantCharacterAction action, 
        TCooldown cooldown
    ) : base(action)
    {
        this.cooldown = cooldown;
        this.target = target;
    }   
    
    public override bool IsReady() => !target.IsActionLocked && cooldown.IsReadyForUse();

    public override bool Attempt()
    {
        if (target.IsActionLocked) return false;

        bool activated = cooldown.AttemptActivation();
        if (activated)
        {   
            action.ActionStart();
        }
        
        return activated;
    }
}

