using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
#nullable enable

[Serializable]
public class ManagedPersistantAction : BaseManagedAction
{
    public readonly Character target;
    readonly OnActionEnded? onEnd;

    public ManagedPersistantAction(
        Character target, 
        IPersistantCharacterAction action, 
        OnActionEnded? onEnd
    ) : base(action)
    {
        this.target = target;
        this.onEnd = onEnd;
    }   

    bool onAction = false;
    
    public override bool IsReady() => !target.IsActionLocked = true;

    public override bool Attempt()
    {
        bool allowed = target.IsActionLocked && onAction = false;

        if (!allowed)
        {   
            action.ActionStart();
        }
        
        return isLocked;
    }

}

