using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
#nullable enable

public class CharacterActionManager 
{
    readonly Character character;
    readonly Transform parentTransform;
    readonly OnActionEnded onActionEnded; //when it is cancellable
    
    IManagedCharacterAction? currentAction;
    GameObject? currentActionObject;
    

    public Character CharacterInstance {get {return character;}}
    public IManagedCharacterAction? CurrentAction {get {return currentAction;}}
    public GameObject? ActionObject {get {return currentActionObject;}}

    public CharacterActionManager(Character character, Transform parentTransform, OnActionEnded onActionEnded)
    {
        this.parentTransform = parentTransform;
        this.character = character;
        this.onActionEnded = onActionEnded;
    }

    

    private TFactory? SetActionInternal<T, TFactory>(
        T target,
        GameObject actionPrefab

    ) where TFactory : class, IBaseActionPrefabFactory<T>
    {
        // Destroy the current action object if it exists
        if (currentActionObject != null)
        {
            Object.Destroy(currentActionObject);
        }

        // Instantiate the new prefab
        currentActionObject = Object.Instantiate(actionPrefab, parentTransform);

        // Fetch the factory component
        TFactory? dataComponent = currentActionObject.GetComponent<TFactory>();
        if (dataComponent == null)
        {
            Debug.LogError($"The prefab {actionPrefab.name} does not implement the required interface!");
            currentActionObject = null;
            return null;
        }

        return dataComponent;
        
    }

    protected void SetAction<T>(T target, GameObject actionPrefab)
    {
        var dataComponent = SetActionInternal<T, IActionPrefabFactory<T>>(
            target,
            actionPrefab
        );

        // Previous func did not fail
        if (dataComponent != null)
        {
            currentAction = dataComponent.GetIManagedAction(target);
        }
    }

    protected void SetCancellableAction<T>(T target, GameObject actionPrefab)
    {
        var dataComponent = SetActionInternal<T, ICancellableActionPrefabFactory<T>>(
            target,
            actionPrefab
        );

        // Previous func did not fail
        if (dataComponent != null)
        {
            currentAction = dataComponent.GetIManagedAction(target, onActionEnded);
        }
       
    }

    
    // warning: no asserted safety for correct prefabs here
    public void SetCharacterAction(GameObject actionPrefab)
    {
        SetAction<Character>(character, actionPrefab);
    }

    public void SetCharacterCancellableAction(GameObject actionPrefab)
    {
        SetCancellableAction<Character>(character, actionPrefab);
    }
}



public class RoninPlayerActionManager : CharacterActionManager
{
    RoninPlayerBehaviourHandler player;

    public RoninPlayerActionManager(
        RoninPlayerBehaviourHandler player,
        Character character, 
        Transform parentTransform, 
        OnActionEnded onActionEnded
    ) : base(character, parentTransform, onActionEnded)
    {
        this.player = player;
    }



    public void SetPlayerAction(GameObject actionPrefab)
    {
        SetAction<AbstractPlayerBehaviourHandler>(player, actionPrefab);
    }

    public void SetPlayerCancellableAction(GameObject actionPrefab)
    {
        SetCancellableAction<AbstractPlayerBehaviourHandler>(player, actionPrefab);
    }



    public void SetRoninPlayerAction(GameObject actionPrefab)
    {
        SetAction<RoninPlayerBehaviourHandler>(player, actionPrefab);
    }

    public void SetRoninPlayerCancellableAction(GameObject actionPrefab)
    {
        SetCancellableAction<RoninPlayerBehaviourHandler>(player, actionPrefab);
    }

}

